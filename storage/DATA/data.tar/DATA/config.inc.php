<?php
define ( 'DB_HOST', 'localhost' );
define ( 'DB_PORT', '3306' );
define ( 'DB_USER', 'root' );
define ( 'DB_PWD', '' );
define ( 'DB_NAME', 'vslab' );
define ( 'URL_APPEDND', '/lms' );
define ( 'EXTERNAL_AUTH', '' );
define ( 'BGCOLOR', '#2B7E50' );
define ( 'URL_ROOT', '/tmp' );
define ( 'PERMEATE', '渗透系统管理平台' );
define ( 'TARGET', '靶机系统管理平台' );
define ( 'EXAMS', '全国大学生信息安全与对抗技术竞赛(ISCC2013)' );
define ( 'CONSOLIDATED', '网络云教育平台' );